:orphan:

.. This page is retained solely for existing links to /distributing/index.html.
   Direct readers to the PPUG instead.

.. _distributing-index:

###############################
  Distributing Python Modules
###############################

.. note::

   Information and guidance on distributing Python modules and packages
   has been moved to the `Python Packaging User Guide`_,
   and the tutorial on `packaging Python projects`_.

   .. _Python Packaging User Guide: https://packaging.python.org/
   .. _packaging Python projects: https://packaging.python.org/en/latest/tutorials/packaging-projects/
