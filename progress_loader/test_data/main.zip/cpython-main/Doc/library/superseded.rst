.. _superseded:

******************
Superseded Modules
******************

The modules described in this chapter are deprecated or :term:`soft deprecated` and only kept for
backwards compatibility. They have been superseded by other modules.


.. toctree::
   :maxdepth: 1

   getopt.rst
   optparse.rst
