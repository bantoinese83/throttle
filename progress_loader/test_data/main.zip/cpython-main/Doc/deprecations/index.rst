Deprecations
============

.. include:: pending-removal-in-3.14.rst

.. include:: pending-removal-in-3.15.rst

.. include:: pending-removal-in-3.16.rst

.. include:: pending-removal-in-future.rst
