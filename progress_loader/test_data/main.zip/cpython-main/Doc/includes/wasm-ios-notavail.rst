.. include for modules that don't work on WASM or iOS

.. availability:: not WASI, not iOS.

   This module does not work or is not available on WebAssembly platforms, or
   on iOS. See :ref:`wasm-availability` for more information on WASM
   availability; see :ref:`iOS-availability` for more information on iOS
   availability.
