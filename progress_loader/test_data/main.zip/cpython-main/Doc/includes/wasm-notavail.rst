.. include for modules that don't work on WASM

.. availability:: not WASI.

   This module does not work or is not available on WebAssembly. See
   :ref:`wasm-availability` for more information.
